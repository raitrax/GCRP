function Global.GetPlayerRgbColour(player)
	return _in(0xE902EF951DCE178F, player, _i, _i, _i)
end
