function Global.N_0x10bd227a753b0d84()
	return _in(0x10BD227A753B0D84, _r, _ri)
end
