function Global.GetRandomFloatInRange(startRange, endRange)
	return _in(0x313CE5879CEB6FCD, startRange, endRange, _r, _rf)
end
