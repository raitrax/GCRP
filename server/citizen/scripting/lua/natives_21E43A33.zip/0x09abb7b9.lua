function Global.N_0x4a7d6e727f941747(p0)
	return _in(0x4A7D6E727F941747, _ii(p0) --[[ may be optional ]], _r, _ri)
end
