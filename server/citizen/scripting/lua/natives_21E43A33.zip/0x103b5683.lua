function Global.N_0xb1cc1b9ec3007a2a(p0)
	return _in(0xB1CC1B9EC3007A2A, p0)
end
