function Global.GetJackTarget(p0)
	return _in(0x5486A79D9FBD342D, p0, _r, _ri)
end
