function Global.N_0x35f7dd45e8c0a16d(p0, p1)
	return _in(0x35F7DD45E8C0A16D, p0, _ii(p1) --[[ may be optional ]], _r)
end
