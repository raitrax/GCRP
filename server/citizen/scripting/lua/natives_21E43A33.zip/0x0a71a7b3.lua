function Global.DrawSprite(textureDict, textureName, screenX, screenY, scaleX, scaleY, heading, colorR, colorG, colorB, colorA)
	return _in(0xE7FFAE5EBF23D890, _ts(textureDict), _ts(textureName), screenX, screenY, scaleX, scaleY, heading, colorR, colorG, colorB, colorA)
end
