function Global.N_0xddf24d535060f811(p0, p1)
	return _in(0xDDF24D535060F811, p0, p1)
end
