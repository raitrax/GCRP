function Global.N_0xeea5ac2eda7c33e8(p0, p1, p2)
	return _in(0xEEA5AC2EDA7C33E8, p0, p1, p2, _r)
end
