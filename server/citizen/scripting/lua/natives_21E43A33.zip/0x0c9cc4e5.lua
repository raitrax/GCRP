function Global.SetEntityCollision(entity, toggle, p2)
	return _in(0x1A9205C1B9EE827F, entity, toggle, p2)
end
