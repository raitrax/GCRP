function Global.N_0x729e3401f0430686()
	return _in(0x729E3401F0430686, _i, _i, _r)
end
