function Global.N_0x8290252fff36acb5(p0, p1, p2, p3)
	return _in(0x8290252FFF36ACB5, p0, p1, p2, p3)
end
