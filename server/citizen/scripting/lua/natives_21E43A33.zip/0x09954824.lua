function Global.PlayVehicleDoorCloseSound(vehicle, p1)
	return _in(0x62A456AA4769EF34, vehicle, p1)
end
