function Global.GetOffsetFromInteriorInWorldCoords(p0, p1, p2, p3)
	return _in(0x9E3B3E6D66F6E22F, p0, p1, p2, p3, _r, _rv)
end
