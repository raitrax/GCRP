function Global.SetUnkMapFlag(flag)
	return _in(0xC5F0A8EBD3F361CE, flag)
end
