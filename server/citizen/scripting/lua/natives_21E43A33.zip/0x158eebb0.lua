function Global.SetEntityQuaternion(entity, x, y, z, w)
	return _in(0x77B21BE7AC540F07, entity, x, y, z, w)
end
