function Global.N_0x56ce820830ef040b(p0)
	return _in(0x56CE820830EF040B, p0, _r, _ri)
end
