function Global.GetEntityPopulationType(entity)
	return _in(0xF6F5161F4534EDFF, entity, _r, _ri)
end
