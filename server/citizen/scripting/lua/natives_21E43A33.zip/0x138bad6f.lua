function Global.ClearAllBrokenGlass()
	return _in(0xB32209EFFDC04913, _r, _ri)
end
