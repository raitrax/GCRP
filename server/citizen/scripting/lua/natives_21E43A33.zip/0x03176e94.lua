function Global.N_0x26695ec767728d84(p0, p1)
	return _in(0x26695EC767728D84, p0, p1)
end
