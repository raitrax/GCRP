function Global.CreateModelSwap(p0, p1, p2, p3, p4, p5, p6)
	return _in(0x92C47782FDA8B2A3, p0, p1, p2, p3, p4, p5, p6)
end
