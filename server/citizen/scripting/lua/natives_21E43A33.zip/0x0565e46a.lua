function Global.N_0xf7f203e31f96f6a1(vehicle, flag)
	return _in(0xF7F203E31F96F6A1, vehicle, flag, _r)
end
