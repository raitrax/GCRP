function Global.SetPedCombatRange(ped, p1)
	return _in(0x3C606747B23E497B, ped, p1)
end
