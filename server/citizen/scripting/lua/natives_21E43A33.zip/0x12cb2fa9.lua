function Global.N_0xeeed8fafec331a70(p0, p1, p2, p3)
	return _in(0xEEED8FAFEC331A70, p0, p1, p2, p3, _r, _ri)
end
