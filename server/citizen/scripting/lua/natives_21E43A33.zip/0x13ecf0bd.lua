function Global.OverridePopscheduleVehicleModel(scheduleId, vehicleHash)
	return _in(0x5F7D596BAC2E7777, scheduleId, _ch(vehicleHash))
end
