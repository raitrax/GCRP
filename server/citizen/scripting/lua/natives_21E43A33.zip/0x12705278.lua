function Global.CanSetExitStateForCamera(p0)
	return _in(0xB2CBCD0930DFB420, p0, _r)
end
