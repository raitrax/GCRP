function Global.N_0x061cb768363d6424(p0, p1)
	return _in(0x061CB768363D6424, p0, p1)
end
