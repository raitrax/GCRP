function Global.GetIsHidef()
	return _in(0x84ED31191CC5D2C9, _r)
end
