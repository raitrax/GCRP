function Global.SetPlayerAngry(player, IsAngry)
	return _in(0xEA241BB04110F091, player, IsAngry)
end
