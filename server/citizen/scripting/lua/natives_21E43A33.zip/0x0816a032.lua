function Global.N_0x06faacd625d80caa(p0)
	return _in(0x06FAACD625D80CAA, p0)
end
