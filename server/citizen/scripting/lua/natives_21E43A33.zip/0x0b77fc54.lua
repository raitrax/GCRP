function Global.ToFloat(value)
	return _in(0xBBDA792448DB5A89, value, _r, _rf)
end
