function Global.ResetPedStrafeClipset(ped)
	return _in(0x20510814175EA477, ped)
end
