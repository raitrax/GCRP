function Global.N_0x621c6e4729388e41(p0)
	return _in(0x621C6E4729388E41, p0, _r)
end
