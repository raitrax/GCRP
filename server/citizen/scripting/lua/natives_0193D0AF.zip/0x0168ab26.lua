function Global.SetVehicleHudSpecialAbilityBarActive(vehicle, p1)
	return _in(0x99C82F8A139F3E4E, vehicle, p1)
end
