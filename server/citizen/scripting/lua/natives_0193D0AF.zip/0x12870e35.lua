function Global.N_0xb50eb4ccb29704ac(p0)
	return _in(0xB50EB4CCB29704AC, p0)
end
