function Global.NetworkBuyFairgroundRide(amountSpent, p1, p2, p3)
	return _in(0x8A7B3952DD64D2B5, amountSpent, p1, p2, p3)
end
