function Global.StopSaveArray()
	return _in(0x04456F95153C6BE4)
end
