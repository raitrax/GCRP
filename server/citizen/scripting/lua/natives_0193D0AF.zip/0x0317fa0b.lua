function Global.PedToNet(ped)
	return _in(0x0EDEC3C276198689, ped, _r, _ri)
end
