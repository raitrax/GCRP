function Global.SetLastDrivenVehicle(vehicle)
	return _in(0xACFB2463CC22BED2, vehicle)
end
