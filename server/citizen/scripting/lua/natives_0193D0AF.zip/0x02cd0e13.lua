function Global.GetCurrentPedWeaponEntityIndex(ped)
	return _in(0x3B390A939AF0B5FC, ped, _r, _ri)
end
