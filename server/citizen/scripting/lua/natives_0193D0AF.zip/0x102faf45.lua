function Global.GetEventExists(p0, p1)
	return _in(0x936E6168A9BCEDB5, p0, p1, _r)
end
