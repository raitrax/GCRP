function Global.N_0x152d90e4c1b4738a()
	return _in(0x152D90E4C1B4738A, _i, _i, _r)
end
