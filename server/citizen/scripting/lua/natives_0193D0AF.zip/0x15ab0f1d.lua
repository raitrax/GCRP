function Global.N_0x8290252fff36acb5(p0, red, green, blue)
	return _in(0x8290252FFF36ACB5, p0, red, green, blue)
end
