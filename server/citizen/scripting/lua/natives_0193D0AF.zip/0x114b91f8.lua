function Global.SetHdArea(x, y, z, ground)
	return _in(0xB85F26619073E775, x, y, z, ground)
end
