function Global.PushScaleformMovieFunctionParameterFloat(value)
	return _in(0xD69736AAE04DB51A, value)
end
