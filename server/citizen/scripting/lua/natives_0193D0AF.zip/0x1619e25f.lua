function Global.GetWeaponClipSize(weaponHash)
	return _in(0x583BE370B1EC6EB4, _ch(weaponHash), _r, _ri)
end
