function Global.NetworkIsCableConnected()
	return _in(0xEFFB25453D8600F9, _r)
end
