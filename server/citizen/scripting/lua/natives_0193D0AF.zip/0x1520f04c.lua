function Global.GetAnimInitialOffsetPosition(animDict, animName, x, y, z, xRot, yRot, zRot, p8, p9)
	return _in(0xBE22B26DD764C040, _ts(animDict), _ts(animName), x, y, z, xRot, yRot, zRot, p8, p9, _r, _rv)
end
