function Global.SetDirectorMode(toggle)
	return _in(0x808519373FD336A3, toggle)
end
