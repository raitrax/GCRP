function Global.NetworkIsChattingInPlatformParty(networkHandle)
	return _in(0x8DE9945BCC9AEC52, _ii(networkHandle) --[[ may be optional ]], _r)
end
