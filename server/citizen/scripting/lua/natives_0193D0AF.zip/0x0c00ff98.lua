function Global.N_0x1201e8a3290a3b98(p0, p1)
	return _in(0x1201E8A3290A3B98, p0, p1)
end
