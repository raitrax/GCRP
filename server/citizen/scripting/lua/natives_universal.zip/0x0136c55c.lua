function Global.N_0x17330ebf2f2124a8()
	return _in(0x17330EBF2F2124A8)
end
