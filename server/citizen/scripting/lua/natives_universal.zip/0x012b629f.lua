--- Does anyone know what this does? I know online modding isn't generally supported especially by the owner of this db, but I first thought this could be used to force ourselves into someones apartment, but I see now that isn't possible.
function Global.ForceRoomForEntity(entity, interiorID, roomHashKey)
	return _in(0x52923C4710DD9907, entity, interiorID, _ch(roomHashKey))
end
