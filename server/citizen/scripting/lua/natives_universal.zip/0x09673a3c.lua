--- Works in Singleplayer too.
-- Actually has a 4th param (BOOL) that sets byte_14273C46C (in b944) to whatever was passed to p3.
function Global.NetworkOverrideClockTime(Hours, Minutes, Seconds)
	return _in(0xE679E3E06E363892, Hours, Minutes, Seconds)
end
