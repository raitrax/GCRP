function Global.N_0x79ab33f0fbfac40c(p0)
	return _in(0x79AB33F0FBFAC40C, p0)
end
