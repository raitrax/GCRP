--- SET_TEXT_??? - Used in golf and golf_mp
function Global.N_0x1185a8087587322c(p0)
	return _in(0x1185A8087587322C, p0)
end
