function Global.N_0xf9c1681347c8bd15(object)
	return _in(0xF9C1681347C8BD15, object)
end
