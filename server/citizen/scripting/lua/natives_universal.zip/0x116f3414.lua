--- Set camera as active/inactive.
function Global.SetCamActive(cam, active)
	return _in(0x026FB97D0A425F84, cam, active)
end
