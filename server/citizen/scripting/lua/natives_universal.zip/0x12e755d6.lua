function Global.IsPedDoingDriveby(ped)
	return _in(0xB2C086CC1BF8F2BF, ped, _r)
end
