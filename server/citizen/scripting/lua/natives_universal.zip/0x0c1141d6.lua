--- The reversed code looks like this (Sasuke78200)
-- //
-- char g_szScriptName[64];
-- char* _0xBE7ACD89(int a_iThreadID)
-- {
-- scrThread* l_pThread;
-- // Get the script thread
-- l_pThread = GetThreadByID(a_iThreadID);
-- if(l_pThread == 0 || l_pThread->m_iThreadState == 2)
-- {
-- strncpy(g_szScriptName, "", 64);
-- }
-- else
-- {
-- strncpy(g_szScriptName, l_pThread->m_szScriptName, 64);
-- }
-- return g_szScriptName;
-- }
function Global.GetNameOfThread(threadId)
	return _in(0x05A42BA9FC8DA96B, threadId, _r, _s)
end
