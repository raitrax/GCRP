function Global.N_0xc79196dcb36f6121(p0)
	return _in(0xC79196DCB36F6121, p0)
end
