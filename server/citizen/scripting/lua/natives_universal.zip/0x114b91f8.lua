--- Harcoded limit for radius is 30.0f
function Global.SetHdArea(x, y, z, radius)
	return _in(0xB85F26619073E775, x, y, z, radius)
end
