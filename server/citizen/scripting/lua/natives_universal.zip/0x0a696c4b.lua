function Global.IsHelpMessageBeingDisplayed()
	return _in(0x4D79439A6B55AC67, _r)
end
