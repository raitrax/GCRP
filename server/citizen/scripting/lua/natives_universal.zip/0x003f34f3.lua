--- returns the players ped used in many functions
function Global.GetPlayerPed(playerId)
	return _in(0x43A66C31C68491C0, playerId, _r, _ri)
end
