function Global.N_0xedf7f927136c224b()
	return _in(0xEDF7F927136C224B, _r, _ri)
end
