--- Returns RGB color of the player
function Global.GetPlayerRgbColour(Player)
	return _in(0xE902EF951DCE178F, Player, _i, _i, _i)
end
