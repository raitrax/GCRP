function Global.SetAllLowPriorityVehicleGeneratorsActive(active)
	return _in(0x608207E7A8FB787C, active)
end
