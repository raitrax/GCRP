--- Removes broken glass particles.
function Global.ClearAllBrokenGlass()
	return _in(0xB32209EFFDC04913)
end
