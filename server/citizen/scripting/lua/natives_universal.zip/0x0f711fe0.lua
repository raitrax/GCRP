--- Makes pedestrians sound their horn longer, faster and more agressive when they use their horn.
function Global.SetAggressiveHorns(toggle)
	return _in(0x395BF71085D1B1D9, toggle)
end
