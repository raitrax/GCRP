function Global.N_0x1f2e4e06dea8992b(p0, p1)
	return _in(0x1F2E4E06DEA8992B, p0, p1)
end
