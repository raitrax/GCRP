function Global.N_0xf8155a7f03ddfc8e(p0)
	return _in(0xF8155A7F03DDFC8E, p0)
end
