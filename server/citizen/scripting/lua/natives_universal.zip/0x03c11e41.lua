function Global.SetPedPreferredCoverSet(ped, itemSet)
	return _in(0x8421EB4DA7E391B9, ped, itemSet)
end
