--- false = Any resolution &lt; 1280x720
-- true = Any resolution &gt;= 1280x720
function Global.GetIsHidef()
	return _in(0x84ED31191CC5D2C9, _r)
end
