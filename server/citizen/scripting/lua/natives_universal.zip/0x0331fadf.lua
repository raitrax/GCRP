function Global.IsStreamingAdditionalText(p0)
	return _in(0x8B6817B71B85EBF0, p0, _r)
end
