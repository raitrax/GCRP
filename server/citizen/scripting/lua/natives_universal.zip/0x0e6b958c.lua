function Global.ScInboxGetEmails(offset, limit)
	return _in(0x040ADDCBAFA1018A, offset, limit)
end
