--- Roll down all the windows of the vehicle passed through the first parameter.
function Global.RollDownWindows(vehicle)
	return _in(0x85796B0549DDE156, vehicle)
end
