--- Jenkins of this native is 0x4293601F. This is the actual name.
function Global.TaskGetOffBoat(ped, boat)
	return _in(0x9C00E77AF14B2DFF, ped, boat)
end
