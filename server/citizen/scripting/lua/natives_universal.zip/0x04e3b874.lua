function Global.NetworkSetEntityCanBlend(entity, toggle)
	return _in(0xD830567D88A1E873, entity, toggle)
end
