function Global.DoesCutsceneEntityExist(cutsceneEntName, modelHash)
	return _in(0x499EF20C5DB25C59, _ts(cutsceneEntName), _ch(modelHash), _r)
end
