--- duration is float here
-- Event types- camx.me/gtav/tasks/shockingevents.txt
function Global.AddShockingEventAtPosition(type, x, y, z, duration)
	return _in(0xD9F8455409B525E9, type, x, y, z, duration, _r, _ri)
end
