--- eventGroup: 0 = CEventGroupScriptAI, 1 = CEventGroupScriptNetwork
function Global.GetEventData(eventGroup, eventIndex, argStructSize)
	return _in(0x2902843FCD2B2D79, eventGroup, eventIndex, _i, argStructSize, _r)
end
