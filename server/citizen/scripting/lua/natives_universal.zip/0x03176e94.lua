--- Works for both player and peds, but some flags don't seem to work for the player (1, for example)
-- 1 - Blocks ragdolling when shot.
-- 2 - Blocks ragdolling when hit by a vehicle. The ped still might play a falling animation.
-- 4 - Blocks ragdolling when set on fire.
-- -----------------------------------------------------------------------
-- There seem to be 26 flags
function Global.N_0x26695ec767728d84(ped, flags)
	return _in(0x26695EC767728D84, ped, flags)
end
