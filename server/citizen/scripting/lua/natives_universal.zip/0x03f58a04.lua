--- The resulting entity can be a Vehicle or Ped.
-- The native is stored between GET_VEHICLE_LIVERY_COUNT and GET_VEHICLE_MAX_BRAKING so the actual name is either GET_VEHICLE_L* or GET_VEHICLE_M*
-- =========================
-- on a side note watching changes in memory this will only store your ped's entityPoolAddress if it's your personal vehicle. So seems to be related to personal vehicles or atleast a specific decor of it maybe.
function Global.GetVehicleOwner(vehicle, entity)
	return _in(0x8F5EBAB1F260CFCE, vehicle, _ii(entity) --[[ may be optional ]], _r)
end
