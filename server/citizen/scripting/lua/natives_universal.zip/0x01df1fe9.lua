--- On PC this is hardcoded to 250.
function Global.NetworkGetMaxFriends()
	return _in(0xAFEBB0D5D8F687D2, _r, _ri)
end
