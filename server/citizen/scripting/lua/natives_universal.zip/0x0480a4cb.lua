--- index always is 2 for xbox 360 controller and razerblade
-- 0, 1 and 2 used in the scripts. 0 is by far the most common of them.
function Global.IsControlPressed(inputGroup, control)
	return _in(0xF3A21BCD95725A4A, inputGroup, control, _r)
end
