--- i don't know what this does
-- ```&lt;pre&gt;
-- void __fastcall OBJECT___0x77F33F2CCF64B3AA_START(scrNativeCallContext *args)
-- {
-- bool p2; // bl@1
-- CObject *pObject; // rax@1
-- scrNativeCallContextArgStruct *pArgs; // rax@1
-- pArgs = args-&gt;pArgs;
-- p2 = pArgs-&gt;a2.BOOL != 0;
-- pObject = getAddressOfObject(pArgs-&gt;a1.Object);
-- if ( pObject )
-- {
-- pObject-&gt;field_425 &amp;= 0xDFu;                // 1101 1111 (clear bit 6)
-- pObject-&gt;field_425 |= 32 * p2;              // bit 6 = p2
-- }
-- }
-- // sfink
-- // note to AB: please set "white-space: pre" in css
-- ```
function Global.SetObjectSomething(object, p1)
	return _in(0x77F33F2CCF64B3AA, object, p1)
end
