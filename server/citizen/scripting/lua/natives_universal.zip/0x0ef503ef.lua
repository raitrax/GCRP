function Global.N_0x1accfba3d8dab2ee(p0, p1)
	return _in(0x1ACCFBA3D8DAB2EE, p0, p1, _r, _ri)
end
