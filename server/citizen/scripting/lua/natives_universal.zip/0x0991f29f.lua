function Global.N_0xb2092a1eaa7fd45f(p0)
	return _in(0xB2092A1EAA7FD45F, p0, _r, _ri)
end
