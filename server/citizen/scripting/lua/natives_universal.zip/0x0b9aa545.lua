--- Only appears twice in the scripts.
-- AI::TASK_RAPPEL_FROM_HELI(PLAYER::PLAYER_PED_ID(), 0x41200000);
-- AI::TASK_RAPPEL_FROM_HELI(a_0, 0x41200000);
-- Fixed, definitely not a float and since it's such a big number obviously not a bool. All though note when I thought it was a bool and set it to 1 it seemed to work that same as int 0x41200000.
-- 0x41200000 = 10.0 as float.
-- Not all helicopters support rappelling.
function Global.TaskRappelFromHeli(ped, unused)
	return _in(0x09693B0312F91649, ped, unused)
end
