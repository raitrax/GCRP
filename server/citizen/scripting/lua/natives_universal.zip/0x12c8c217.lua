function Global.N_0x437138b6a830166a()
	return _in(0x437138B6A830166A)
end
