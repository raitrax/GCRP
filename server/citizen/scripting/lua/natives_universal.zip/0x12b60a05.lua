function Global.N_0xc6dc823253fbb366()
	return _in(0xC6DC823253FBB366, _r)
end
