function Global.NetworkSessionWasInvited()
	return _in(0x23DFB504655D0CE4, _r)
end
