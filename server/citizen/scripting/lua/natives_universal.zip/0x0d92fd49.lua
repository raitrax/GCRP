--- landing gear states:
-- 0: Deployed
-- 1: Closing
-- 2: Opening
-- 3: Retracted
function Global.GetVehicleLandingGear(vehicle)
	return _in(0x9B0F3DCA3DB0F4CD, vehicle, _r, _ri)
end
