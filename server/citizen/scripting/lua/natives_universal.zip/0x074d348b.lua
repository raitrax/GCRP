--- ease - smooth transition between the camera's positions
-- easeTime - Time in milliseconds for the transition to happen
-- If you have created a script (rendering) camera, and want to go back to the
-- character (gameplay) camera, call this native with render set to 0.
-- Setting ease to 1 will smooth the transition.
function Global.RenderScriptCams(render, ease, easeTime, p3, p4)
	return _in(0x07E5B515DB0636FC, render, ease, easeTime, p3, p4)
end
