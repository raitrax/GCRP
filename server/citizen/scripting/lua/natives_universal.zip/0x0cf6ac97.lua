--- if (!ENTITY::DOES_ENTITY_BELONG_TO_THIS_SCRIPT(g_10A5A._f8B[a_0/*1*/], 1)) {
-- sub_20af7("No longer needed: Vehicle owned by other script");
-- if ((((a_0 == 24) &amp;&amp; (!sub_3a04(g_10A5A._f8B[a_0/*1*/]))) &amp;&amp; (!sub_39c9(g_10A5A._f8B[a_0/*1*/]))) &amp;&amp; (ENTITY::GET_ENTITY_MODEL(g_10A5A._f8B[a_0/*1*/]) != ${monster})) {
-- VEHICLE::_428BACCDF5E26EAD(g_10A5A._f8B[a_0/*1*/], 1);
-- }
-- g_10A5A._f8B[a_0/*1*/] = 0;
-- g_10A5A[a_0/*1*/] = 1;
-- sub_20ada(a_0);
-- return ;
-- }
function Global.N_0x428baccdf5e26ead(vehicle, p1)
	return _in(0x428BACCDF5E26EAD, vehicle, p1)
end
