--- If toggle is true, the map is shown in full screen
-- If toggle is false, the map is shown in normal mode
function Global.SetMapFullScreen(toggle)
	return _in(0x5354C5BA2EA868A4, toggle)
end
